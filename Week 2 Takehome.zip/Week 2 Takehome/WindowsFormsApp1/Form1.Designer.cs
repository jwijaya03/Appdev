﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_first = new System.Windows.Forms.TextBox();
            this.tb_second = new System.Windows.Forms.TextBox();
            this.tb_third = new System.Windows.Forms.TextBox();
            this.tb_fourth = new System.Windows.Forms.TextBox();
            this.tb_fifth = new System.Windows.Forms.TextBox();
            this.bt_submit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel_words = new System.Windows.Forms.Panel();
            this.Chosen = new System.Windows.Forms.Label();
            this.zButton = new System.Windows.Forms.Button();
            this.yButton = new System.Windows.Forms.Button();
            this.xButton = new System.Windows.Forms.Button();
            this.wButton = new System.Windows.Forms.Button();
            this.vButton = new System.Windows.Forms.Button();
            this.uButton = new System.Windows.Forms.Button();
            this.tButton = new System.Windows.Forms.Button();
            this.sButton = new System.Windows.Forms.Button();
            this.rButton = new System.Windows.Forms.Button();
            this.qButton = new System.Windows.Forms.Button();
            this.pButton = new System.Windows.Forms.Button();
            this.oButton = new System.Windows.Forms.Button();
            this.nButton = new System.Windows.Forms.Button();
            this.mButton = new System.Windows.Forms.Button();
            this.lButton = new System.Windows.Forms.Button();
            this.kButton = new System.Windows.Forms.Button();
            this.jButton = new System.Windows.Forms.Button();
            this.iButton = new System.Windows.Forms.Button();
            this.hButton = new System.Windows.Forms.Button();
            this.gButton = new System.Windows.Forms.Button();
            this.fButton = new System.Windows.Forms.Button();
            this.eButton = new System.Windows.Forms.Button();
            this.dButton = new System.Windows.Forms.Button();
            this.cButton = new System.Windows.Forms.Button();
            this.bButton = new System.Windows.Forms.Button();
            this.aButton = new System.Windows.Forms.Button();
            this.fifth = new System.Windows.Forms.Label();
            this.fourth = new System.Windows.Forms.Label();
            this.third = new System.Windows.Forms.Label();
            this.second = new System.Windows.Forms.Label();
            this.first = new System.Windows.Forms.Label();
            this.panel_game = new System.Windows.Forms.Panel();
            this.panel_words.SuspendLayout();
            this.panel_game.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_first
            // 
            this.tb_first.Location = new System.Drawing.Point(89, 14);
            this.tb_first.Name = "tb_first";
            this.tb_first.Size = new System.Drawing.Size(100, 22);
            this.tb_first.TabIndex = 0;
            // 
            // tb_second
            // 
            this.tb_second.Location = new System.Drawing.Point(89, 42);
            this.tb_second.Name = "tb_second";
            this.tb_second.Size = new System.Drawing.Size(100, 22);
            this.tb_second.TabIndex = 1;
            // 
            // tb_third
            // 
            this.tb_third.Location = new System.Drawing.Point(89, 70);
            this.tb_third.Name = "tb_third";
            this.tb_third.Size = new System.Drawing.Size(100, 22);
            this.tb_third.TabIndex = 2;
            // 
            // tb_fourth
            // 
            this.tb_fourth.Location = new System.Drawing.Point(89, 98);
            this.tb_fourth.Name = "tb_fourth";
            this.tb_fourth.Size = new System.Drawing.Size(100, 22);
            this.tb_fourth.TabIndex = 3;
            // 
            // tb_fifth
            // 
            this.tb_fifth.Location = new System.Drawing.Point(89, 126);
            this.tb_fifth.Name = "tb_fifth";
            this.tb_fifth.Size = new System.Drawing.Size(100, 22);
            this.tb_fifth.TabIndex = 4;
            // 
            // bt_submit
            // 
            this.bt_submit.Location = new System.Drawing.Point(100, 154);
            this.bt_submit.Name = "bt_submit";
            this.bt_submit.Size = new System.Drawing.Size(75, 23);
            this.bt_submit.TabIndex = 5;
            this.bt_submit.Text = "Play";
            this.bt_submit.UseVisualStyleBackColor = true;
            this.bt_submit.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Text 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Text 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Text 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Text 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Text 5";
            // 
            // panel_words
            // 
            this.panel_words.Controls.Add(this.tb_third);
            this.panel_words.Controls.Add(this.label5);
            this.panel_words.Controls.Add(this.tb_first);
            this.panel_words.Controls.Add(this.label4);
            this.panel_words.Controls.Add(this.tb_second);
            this.panel_words.Controls.Add(this.label3);
            this.panel_words.Controls.Add(this.tb_fourth);
            this.panel_words.Controls.Add(this.label2);
            this.panel_words.Controls.Add(this.tb_fifth);
            this.panel_words.Controls.Add(this.label1);
            this.panel_words.Controls.Add(this.bt_submit);
            this.panel_words.Location = new System.Drawing.Point(12, 12);
            this.panel_words.Name = "panel_words";
            this.panel_words.Size = new System.Drawing.Size(205, 184);
            this.panel_words.TabIndex = 11;
            this.panel_words.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_words_Paint);
            // 
            // Chosen
            // 
            this.Chosen.AutoSize = true;
            this.Chosen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chosen.Location = new System.Drawing.Point(439, 67);
            this.Chosen.Name = "Chosen";
            this.Chosen.Size = new System.Drawing.Size(75, 25);
            this.Chosen.TabIndex = 65;
            this.Chosen.Text = "Words";
            // 
            // zButton
            // 
            this.zButton.Location = new System.Drawing.Point(101, 222);
            this.zButton.Name = "zButton";
            this.zButton.Size = new System.Drawing.Size(55, 42);
            this.zButton.TabIndex = 64;
            this.zButton.Text = "Z";
            this.zButton.UseVisualStyleBackColor = true;
            this.zButton.Click += new System.EventHandler(this.zButton_Click);
            // 
            // yButton
            // 
            this.yButton.Location = new System.Drawing.Point(331, 126);
            this.yButton.Name = "yButton";
            this.yButton.Size = new System.Drawing.Size(45, 42);
            this.yButton.TabIndex = 63;
            this.yButton.Text = "Y";
            this.yButton.UseVisualStyleBackColor = true;
            this.yButton.Click += new System.EventHandler(this.yButton_Click);
            // 
            // xButton
            // 
            this.xButton.Location = new System.Drawing.Point(163, 222);
            this.xButton.Name = "xButton";
            this.xButton.Size = new System.Drawing.Size(54, 42);
            this.xButton.TabIndex = 62;
            this.xButton.Text = "X";
            this.xButton.UseVisualStyleBackColor = true;
            this.xButton.Click += new System.EventHandler(this.xButton_Click);
            // 
            // wButton
            // 
            this.wButton.Location = new System.Drawing.Point(109, 126);
            this.wButton.Name = "wButton";
            this.wButton.Size = new System.Drawing.Size(47, 42);
            this.wButton.TabIndex = 61;
            this.wButton.Text = "W";
            this.wButton.UseVisualStyleBackColor = true;
            this.wButton.Click += new System.EventHandler(this.wButton_Click);
            // 
            // vButton
            // 
            this.vButton.Location = new System.Drawing.Point(281, 222);
            this.vButton.Name = "vButton";
            this.vButton.Size = new System.Drawing.Size(54, 42);
            this.vButton.TabIndex = 60;
            this.vButton.Text = "V";
            this.vButton.UseVisualStyleBackColor = true;
            this.vButton.Click += new System.EventHandler(this.vButton_Click);
            // 
            // uButton
            // 
            this.uButton.Location = new System.Drawing.Point(382, 126);
            this.uButton.Name = "uButton";
            this.uButton.Size = new System.Drawing.Size(47, 42);
            this.uButton.TabIndex = 59;
            this.uButton.Text = "U";
            this.uButton.UseVisualStyleBackColor = true;
            this.uButton.Click += new System.EventHandler(this.uButton_Click);
            // 
            // tButton
            // 
            this.tButton.Location = new System.Drawing.Point(270, 126);
            this.tButton.Name = "tButton";
            this.tButton.Size = new System.Drawing.Size(55, 42);
            this.tButton.TabIndex = 58;
            this.tButton.Text = "T";
            this.tButton.UseVisualStyleBackColor = true;
            this.tButton.Click += new System.EventHandler(this.tButton_Click);
            // 
            // sButton
            // 
            this.sButton.Location = new System.Drawing.Point(124, 174);
            this.sButton.Name = "sButton";
            this.sButton.Size = new System.Drawing.Size(46, 42);
            this.sButton.TabIndex = 57;
            this.sButton.Text = "S";
            this.sButton.UseVisualStyleBackColor = true;
            this.sButton.Click += new System.EventHandler(this.sButton_Click);
            // 
            // rButton
            // 
            this.rButton.Location = new System.Drawing.Point(213, 126);
            this.rButton.Name = "rButton";
            this.rButton.Size = new System.Drawing.Size(51, 42);
            this.rButton.TabIndex = 56;
            this.rButton.Text = "R";
            this.rButton.UseVisualStyleBackColor = true;
            this.rButton.Click += new System.EventHandler(this.rButton_Click);
            // 
            // qButton
            // 
            this.qButton.Location = new System.Drawing.Point(56, 126);
            this.qButton.Name = "qButton";
            this.qButton.Size = new System.Drawing.Size(45, 42);
            this.qButton.TabIndex = 55;
            this.qButton.Text = "Q";
            this.qButton.UseVisualStyleBackColor = true;
            this.qButton.Click += new System.EventHandler(this.qButton_Click);
            // 
            // pButton
            // 
            this.pButton.Location = new System.Drawing.Point(550, 126);
            this.pButton.Name = "pButton";
            this.pButton.Size = new System.Drawing.Size(56, 42);
            this.pButton.TabIndex = 54;
            this.pButton.Text = "P";
            this.pButton.UseVisualStyleBackColor = true;
            this.pButton.Click += new System.EventHandler(this.pButton_Click);
            // 
            // oButton
            // 
            this.oButton.Location = new System.Drawing.Point(492, 126);
            this.oButton.Name = "oButton";
            this.oButton.Size = new System.Drawing.Size(52, 42);
            this.oButton.TabIndex = 53;
            this.oButton.Text = "O";
            this.oButton.UseVisualStyleBackColor = true;
            this.oButton.Click += new System.EventHandler(this.oButton_Click);
            // 
            // nButton
            // 
            this.nButton.Location = new System.Drawing.Point(402, 222);
            this.nButton.Name = "nButton";
            this.nButton.Size = new System.Drawing.Size(56, 42);
            this.nButton.TabIndex = 52;
            this.nButton.Text = "N";
            this.nButton.UseVisualStyleBackColor = true;
            this.nButton.Click += new System.EventHandler(this.nButton_Click);
            // 
            // mButton
            // 
            this.mButton.Location = new System.Drawing.Point(464, 222);
            this.mButton.Name = "mButton";
            this.mButton.Size = new System.Drawing.Size(50, 42);
            this.mButton.TabIndex = 51;
            this.mButton.Text = "M";
            this.mButton.UseVisualStyleBackColor = true;
            this.mButton.Click += new System.EventHandler(this.mButton_Click);
            // 
            // lButton
            // 
            this.lButton.Location = new System.Drawing.Point(527, 174);
            this.lButton.Name = "lButton";
            this.lButton.Size = new System.Drawing.Size(52, 42);
            this.lButton.TabIndex = 50;
            this.lButton.Text = "L";
            this.lButton.UseVisualStyleBackColor = true;
            this.lButton.Click += new System.EventHandler(this.lButton_Click);
            // 
            // kButton
            // 
            this.kButton.Location = new System.Drawing.Point(471, 174);
            this.kButton.Name = "kButton";
            this.kButton.Size = new System.Drawing.Size(50, 42);
            this.kButton.TabIndex = 49;
            this.kButton.Text = "K";
            this.kButton.UseVisualStyleBackColor = true;
            this.kButton.Click += new System.EventHandler(this.kButton_Click);
            // 
            // jButton
            // 
            this.jButton.Location = new System.Drawing.Point(411, 174);
            this.jButton.Name = "jButton";
            this.jButton.Size = new System.Drawing.Size(52, 42);
            this.jButton.TabIndex = 48;
            this.jButton.Text = "J";
            this.jButton.UseVisualStyleBackColor = true;
            this.jButton.Click += new System.EventHandler(this.jButton_Click);
            // 
            // iButton
            // 
            this.iButton.Location = new System.Drawing.Point(435, 126);
            this.iButton.Name = "iButton";
            this.iButton.Size = new System.Drawing.Size(51, 42);
            this.iButton.TabIndex = 47;
            this.iButton.Text = "I";
            this.iButton.UseVisualStyleBackColor = true;
            this.iButton.Click += new System.EventHandler(this.iButton_Click);
            // 
            // hButton
            // 
            this.hButton.Location = new System.Drawing.Point(349, 174);
            this.hButton.Name = "hButton";
            this.hButton.Size = new System.Drawing.Size(56, 42);
            this.hButton.TabIndex = 46;
            this.hButton.Text = "H";
            this.hButton.UseVisualStyleBackColor = true;
            this.hButton.Click += new System.EventHandler(this.hButton_Click);
            // 
            // gButton
            // 
            this.gButton.Location = new System.Drawing.Point(292, 174);
            this.gButton.Name = "gButton";
            this.gButton.Size = new System.Drawing.Size(51, 42);
            this.gButton.TabIndex = 45;
            this.gButton.Text = "G";
            this.gButton.UseVisualStyleBackColor = true;
            this.gButton.Click += new System.EventHandler(this.gButton_Click);
            // 
            // fButton
            // 
            this.fButton.Location = new System.Drawing.Point(235, 174);
            this.fButton.Name = "fButton";
            this.fButton.Size = new System.Drawing.Size(51, 42);
            this.fButton.TabIndex = 44;
            this.fButton.Text = "F";
            this.fButton.UseVisualStyleBackColor = true;
            this.fButton.Click += new System.EventHandler(this.fButton_Click);
            // 
            // eButton
            // 
            this.eButton.Location = new System.Drawing.Point(162, 126);
            this.eButton.Name = "eButton";
            this.eButton.Size = new System.Drawing.Size(44, 42);
            this.eButton.TabIndex = 43;
            this.eButton.Text = "E";
            this.eButton.UseVisualStyleBackColor = true;
            this.eButton.Click += new System.EventHandler(this.eButton_Click);
            // 
            // dButton
            // 
            this.dButton.Location = new System.Drawing.Point(177, 174);
            this.dButton.Name = "dButton";
            this.dButton.Size = new System.Drawing.Size(52, 42);
            this.dButton.TabIndex = 42;
            this.dButton.Text = "D";
            this.dButton.UseVisualStyleBackColor = true;
            this.dButton.Click += new System.EventHandler(this.dButton_Click);
            // 
            // cButton
            // 
            this.cButton.Location = new System.Drawing.Point(223, 222);
            this.cButton.Name = "cButton";
            this.cButton.Size = new System.Drawing.Size(52, 42);
            this.cButton.TabIndex = 41;
            this.cButton.Text = "C";
            this.cButton.UseVisualStyleBackColor = true;
            this.cButton.Click += new System.EventHandler(this.cButton_Click);
            // 
            // bButton
            // 
            this.bButton.Location = new System.Drawing.Point(342, 222);
            this.bButton.Name = "bButton";
            this.bButton.Size = new System.Drawing.Size(55, 42);
            this.bButton.TabIndex = 40;
            this.bButton.Text = "B";
            this.bButton.UseVisualStyleBackColor = true;
            this.bButton.Click += new System.EventHandler(this.bButton_Click);
            // 
            // aButton
            // 
            this.aButton.Location = new System.Drawing.Point(72, 174);
            this.aButton.Name = "aButton";
            this.aButton.Size = new System.Drawing.Size(46, 42);
            this.aButton.TabIndex = 39;
            this.aButton.Text = "A";
            this.aButton.UseVisualStyleBackColor = true;
            this.aButton.Click += new System.EventHandler(this.aButton_Click);
            // 
            // fifth
            // 
            this.fifth.AutoSize = true;
            this.fifth.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fifth.Location = new System.Drawing.Point(375, 55);
            this.fifth.Name = "fifth";
            this.fifth.Size = new System.Drawing.Size(36, 38);
            this.fifth.TabIndex = 38;
            this.fifth.Text = "_";
            // 
            // fourth
            // 
            this.fourth.AutoSize = true;
            this.fourth.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourth.Location = new System.Drawing.Point(333, 55);
            this.fourth.Name = "fourth";
            this.fourth.Size = new System.Drawing.Size(36, 38);
            this.fourth.TabIndex = 37;
            this.fourth.Text = "_";
            // 
            // third
            // 
            this.third.AutoSize = true;
            this.third.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.third.Location = new System.Drawing.Point(291, 55);
            this.third.Name = "third";
            this.third.Size = new System.Drawing.Size(36, 38);
            this.third.TabIndex = 36;
            this.third.Text = "_";
            // 
            // second
            // 
            this.second.AutoSize = true;
            this.second.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.second.Location = new System.Drawing.Point(249, 55);
            this.second.Name = "second";
            this.second.Size = new System.Drawing.Size(36, 38);
            this.second.TabIndex = 35;
            this.second.Text = "_";
            // 
            // first
            // 
            this.first.AutoSize = true;
            this.first.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.first.Location = new System.Drawing.Point(207, 55);
            this.first.Name = "first";
            this.first.Size = new System.Drawing.Size(36, 38);
            this.first.TabIndex = 34;
            this.first.Text = "_";
            // 
            // panel_game
            // 
            this.panel_game.Controls.Add(this.first);
            this.panel_game.Controls.Add(this.Chosen);
            this.panel_game.Controls.Add(this.second);
            this.panel_game.Controls.Add(this.zButton);
            this.panel_game.Controls.Add(this.third);
            this.panel_game.Controls.Add(this.yButton);
            this.panel_game.Controls.Add(this.fourth);
            this.panel_game.Controls.Add(this.xButton);
            this.panel_game.Controls.Add(this.fifth);
            this.panel_game.Controls.Add(this.wButton);
            this.panel_game.Controls.Add(this.aButton);
            this.panel_game.Controls.Add(this.vButton);
            this.panel_game.Controls.Add(this.bButton);
            this.panel_game.Controls.Add(this.uButton);
            this.panel_game.Controls.Add(this.cButton);
            this.panel_game.Controls.Add(this.tButton);
            this.panel_game.Controls.Add(this.dButton);
            this.panel_game.Controls.Add(this.sButton);
            this.panel_game.Controls.Add(this.eButton);
            this.panel_game.Controls.Add(this.rButton);
            this.panel_game.Controls.Add(this.fButton);
            this.panel_game.Controls.Add(this.qButton);
            this.panel_game.Controls.Add(this.gButton);
            this.panel_game.Controls.Add(this.pButton);
            this.panel_game.Controls.Add(this.hButton);
            this.panel_game.Controls.Add(this.oButton);
            this.panel_game.Controls.Add(this.iButton);
            this.panel_game.Controls.Add(this.nButton);
            this.panel_game.Controls.Add(this.jButton);
            this.panel_game.Controls.Add(this.mButton);
            this.panel_game.Controls.Add(this.kButton);
            this.panel_game.Controls.Add(this.lButton);
            this.panel_game.Location = new System.Drawing.Point(238, 12);
            this.panel_game.Name = "panel_game";
            this.panel_game.Size = new System.Drawing.Size(640, 341);
            this.panel_game.TabIndex = 66;
            this.panel_game.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 485);
            this.Controls.Add(this.panel_game);
            this.Controls.Add(this.panel_words);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_words.ResumeLayout(false);
            this.panel_words.PerformLayout();
            this.panel_game.ResumeLayout(false);
            this.panel_game.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_first;
        private System.Windows.Forms.TextBox tb_second;
        private System.Windows.Forms.TextBox tb_third;
        private System.Windows.Forms.TextBox tb_fourth;
        private System.Windows.Forms.TextBox tb_fifth;
        private System.Windows.Forms.Button bt_submit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel_words;
        private System.Windows.Forms.Label Chosen;
        private System.Windows.Forms.Button zButton;
        private System.Windows.Forms.Button yButton;
        private System.Windows.Forms.Button xButton;
        private System.Windows.Forms.Button wButton;
        private System.Windows.Forms.Button vButton;
        private System.Windows.Forms.Button uButton;
        private System.Windows.Forms.Button tButton;
        private System.Windows.Forms.Button sButton;
        private System.Windows.Forms.Button rButton;
        private System.Windows.Forms.Button qButton;
        private System.Windows.Forms.Button pButton;
        private System.Windows.Forms.Button oButton;
        private System.Windows.Forms.Button nButton;
        private System.Windows.Forms.Button mButton;
        private System.Windows.Forms.Button lButton;
        private System.Windows.Forms.Button kButton;
        private System.Windows.Forms.Button jButton;
        private System.Windows.Forms.Button iButton;
        private System.Windows.Forms.Button hButton;
        private System.Windows.Forms.Button gButton;
        private System.Windows.Forms.Button fButton;
        private System.Windows.Forms.Button eButton;
        private System.Windows.Forms.Button dButton;
        private System.Windows.Forms.Button cButton;
        private System.Windows.Forms.Button bButton;
        private System.Windows.Forms.Button aButton;
        private System.Windows.Forms.Label fifth;
        private System.Windows.Forms.Label fourth;
        private System.Windows.Forms.Label third;
        private System.Windows.Forms.Label second;
        private System.Windows.Forms.Label first;
        private System.Windows.Forms.Panel panel_game;
    }
}

