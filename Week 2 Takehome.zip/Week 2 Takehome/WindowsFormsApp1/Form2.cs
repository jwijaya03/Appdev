﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void Chosen_word_TextChanged(object sender, EventArgs e)
        {

        }

        private void aButton_Click(object sender, EventArgs e)
        {
            /*if (checkwords = first)
            {
            replace first dengan word yang ditekan (first.text = checkwords)
            }
            */
        }
        
    }
}
