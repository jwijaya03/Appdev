﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        string[] words = new string[5];

        public Form1()
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tb_first.Text.Length > 5 || tb_first.Text.Length < 5)
            {
                MessageBox.Show("Error: Textbox 1 Must be 5 Words Exact.");
            }
            else if (tb_second.Text.Length > 5 || tb_second.Text.Length < 5)
            {
                MessageBox.Show("Error: Textbox 2 Must be 5 Words Exact.");
            }
            else if (tb_third.Text.Length > 5 || tb_third.Text.Length < 5)
            {
                MessageBox.Show("Error: Textbox 3 Must be 5 Words Exact.");
            }
            else if (tb_fourth.Text.Length > 5 || tb_fourth.Text.Length < 5)
            {
                MessageBox.Show("Error: Textbox 4 Must be 5 Words Exact.");
            }
            else if (tb_fifth.Text.Length > 5 || tb_fifth.Text.Length < 5)
            {
                MessageBox.Show("Error: Textbox 5 Must be 5 Words Exact.");
            }
            else
            {
                if (tb_first.Text == tb_second.Text)
                {
                    MessageBox.Show("Error: Textbox 1 and 2 Are the same.");
                }
                else if (tb_first.Text == tb_third.Text)
                {
                    MessageBox.Show("Error: Textbox 1 and 3 Are the same.");
                }
                else if (tb_first.Text == tb_fourth.Text)
                {
                    MessageBox.Show("Error: Textbox 1 and 4 Are the same.");
                }
                else if (tb_first.Text == tb_fifth.Text)
                {
                    MessageBox.Show("Error: Textbox 1 and 5 Are the same.");
                }
                else if (tb_second.Text == tb_third.Text)
                {
                    MessageBox.Show("Error: Textbox 2 and 3 Are the same.");
                }
                else if (tb_second.Text == tb_fourth.Text)
                {
                    MessageBox.Show("Error: Textbox 2 and 4 Are the same.");
                }
                else if (tb_second.Text == tb_fifth.Text)
                {
                    MessageBox.Show("Error: Textbox 2 and 5 Are the same.");
                }
                else if (tb_third.Text == tb_fourth.Text)
                {
                    MessageBox.Show("Error: Textbox 3 and 4 Are the same.");
                }
                else if (tb_third.Text == tb_fifth.Text)
                {
                    MessageBox.Show("Error: Textbox 3 and 5 Are the same.");
                }
                else if (tb_fourth.Text == tb_fifth.Text)
                {
                    MessageBox.Show("Error: Textbox 4 and 5 Are the same.");
                }
                else
                {
                    words[0] = tb_first.Text;
                    words[1] = tb_second.Text;
                    words[2] = tb_third.Text;
                    words[3] = tb_fourth.Text;
                    words[4] = tb_fifth.Text;
                    Random random = new Random();
                    string chosen_word = words[new Random().Next(0, words.Length)];
                    panel_words.Visible = false;
                    panel_game.Visible = true;
                    Chosen.Text = chosen_word;
                    MessageBox.Show("Let the Game Begin");
                    

                }
            }

        }
         
        private void panel_words_Paint(object sender, PaintEventArgs e)
        {

        }

        private void wButton_Click(object sender, EventArgs e)
        {

        }

        private void yButton_Click(object sender, EventArgs e)
        {

        }

        private void xButton_Click(object sender, EventArgs e)
        {

        }

        private void tButton_Click(object sender, EventArgs e)
        {

        }

        private void aButton_Click(object sender, EventArgs e)
        {

        }

        private void vButton_Click(object sender, EventArgs e)
        {

        }

        private void bButton_Click(object sender, EventArgs e)
        {

        }

        private void uButton_Click(object sender, EventArgs e)
        {

        }

        private void cButton_Click(object sender, EventArgs e)
        {

        }

        private void zButton_Click(object sender, EventArgs e)
        {

        }

        private void dButton_Click(object sender, EventArgs e)
        {

        }

        private void sButton_Click(object sender, EventArgs e)
        {

        }

        private void eButton_Click(object sender, EventArgs e)
        {

        }

        private void rButton_Click(object sender, EventArgs e)
        {

        }

        private void fButton_Click(object sender, EventArgs e)
        {

        }

        private void qButton_Click(object sender, EventArgs e)
        {

        }

        private void gButton_Click(object sender, EventArgs e)
        {

        }

        private void pButton_Click(object sender, EventArgs e)
        {

        }

        private void hButton_Click(object sender, EventArgs e)
        {

        }

        private void oButton_Click(object sender, EventArgs e)
        {

        }

        private void iButton_Click(object sender, EventArgs e)
        {

        }

        private void nButton_Click(object sender, EventArgs e)
        {

        }

        private void jButton_Click(object sender, EventArgs e)
        {

        }

        private void mButton_Click(object sender, EventArgs e)
        {

        }

        private void kButton_Click(object sender, EventArgs e)
        {

        }

        private void lButton_Click(object sender, EventArgs e)
        {

        }
    }
}
