﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.first = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.second = new System.Windows.Forms.Label();
            this.third = new System.Windows.Forms.Label();
            this.fourth = new System.Windows.Forms.Label();
            this.fifth = new System.Windows.Forms.Label();
            this.aButton = new System.Windows.Forms.Button();
            this.bButton = new System.Windows.Forms.Button();
            this.cButton = new System.Windows.Forms.Button();
            this.dButton = new System.Windows.Forms.Button();
            this.eButton = new System.Windows.Forms.Button();
            this.fButton = new System.Windows.Forms.Button();
            this.gButton = new System.Windows.Forms.Button();
            this.hButton = new System.Windows.Forms.Button();
            this.iButton = new System.Windows.Forms.Button();
            this.jButton = new System.Windows.Forms.Button();
            this.kButton = new System.Windows.Forms.Button();
            this.lButton = new System.Windows.Forms.Button();
            this.mButton = new System.Windows.Forms.Button();
            this.nButton = new System.Windows.Forms.Button();
            this.oButton = new System.Windows.Forms.Button();
            this.pButton = new System.Windows.Forms.Button();
            this.qButton = new System.Windows.Forms.Button();
            this.rButton = new System.Windows.Forms.Button();
            this.sButton = new System.Windows.Forms.Button();
            this.tButton = new System.Windows.Forms.Button();
            this.uButton = new System.Windows.Forms.Button();
            this.vButton = new System.Windows.Forms.Button();
            this.wButton = new System.Windows.Forms.Button();
            this.xButton = new System.Windows.Forms.Button();
            this.yButton = new System.Windows.Forms.Button();
            this.zButton = new System.Windows.Forms.Button();
            this.Chosen_word = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // first
            // 
            this.first.AutoSize = true;
            this.first.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.first.Location = new System.Drawing.Point(149, 35);
            this.first.Name = "first";
            this.first.Size = new System.Drawing.Size(36, 38);
            this.first.TabIndex = 0;
            this.first.Text = "_";
            // 
            // second
            // 
            this.second.AutoSize = true;
            this.second.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.second.Location = new System.Drawing.Point(216, 35);
            this.second.Name = "second";
            this.second.Size = new System.Drawing.Size(36, 38);
            this.second.TabIndex = 2;
            this.second.Text = "_";
            // 
            // third
            // 
            this.third.AutoSize = true;
            this.third.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.third.Location = new System.Drawing.Point(281, 35);
            this.third.Name = "third";
            this.third.Size = new System.Drawing.Size(36, 38);
            this.third.TabIndex = 3;
            this.third.Text = "_";
            // 
            // fourth
            // 
            this.fourth.AutoSize = true;
            this.fourth.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fourth.Location = new System.Drawing.Point(350, 35);
            this.fourth.Name = "fourth";
            this.fourth.Size = new System.Drawing.Size(36, 38);
            this.fourth.TabIndex = 4;
            this.fourth.Text = "_";
            // 
            // fifth
            // 
            this.fifth.AutoSize = true;
            this.fifth.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fifth.Location = new System.Drawing.Point(415, 35);
            this.fifth.Name = "fifth";
            this.fifth.Size = new System.Drawing.Size(36, 38);
            this.fifth.TabIndex = 5;
            this.fifth.Text = "_";
            // 
            // aButton
            // 
            this.aButton.Location = new System.Drawing.Point(42, 111);
            this.aButton.Name = "aButton";
            this.aButton.Size = new System.Drawing.Size(73, 42);
            this.aButton.TabIndex = 6;
            this.aButton.Text = "A";
            this.aButton.UseVisualStyleBackColor = true;
            this.aButton.Click += new System.EventHandler(this.aButton_Click);
            // 
            // bButton
            // 
            this.bButton.Location = new System.Drawing.Point(132, 111);
            this.bButton.Name = "bButton";
            this.bButton.Size = new System.Drawing.Size(73, 42);
            this.bButton.TabIndex = 7;
            this.bButton.Text = "B";
            this.bButton.UseVisualStyleBackColor = true;
            // 
            // cButton
            // 
            this.cButton.Location = new System.Drawing.Point(236, 111);
            this.cButton.Name = "cButton";
            this.cButton.Size = new System.Drawing.Size(73, 42);
            this.cButton.TabIndex = 8;
            this.cButton.Text = "C";
            this.cButton.UseVisualStyleBackColor = true;
            // 
            // dButton
            // 
            this.dButton.Location = new System.Drawing.Point(338, 111);
            this.dButton.Name = "dButton";
            this.dButton.Size = new System.Drawing.Size(73, 42);
            this.dButton.TabIndex = 9;
            this.dButton.Text = "D";
            this.dButton.UseVisualStyleBackColor = true;
            // 
            // eButton
            // 
            this.eButton.Location = new System.Drawing.Point(428, 111);
            this.eButton.Name = "eButton";
            this.eButton.Size = new System.Drawing.Size(73, 42);
            this.eButton.TabIndex = 10;
            this.eButton.Text = "E";
            this.eButton.UseVisualStyleBackColor = true;
            // 
            // fButton
            // 
            this.fButton.Location = new System.Drawing.Point(519, 111);
            this.fButton.Name = "fButton";
            this.fButton.Size = new System.Drawing.Size(73, 42);
            this.fButton.TabIndex = 11;
            this.fButton.Text = "F";
            this.fButton.UseVisualStyleBackColor = true;
            // 
            // gButton
            // 
            this.gButton.Location = new System.Drawing.Point(598, 111);
            this.gButton.Name = "gButton";
            this.gButton.Size = new System.Drawing.Size(73, 42);
            this.gButton.TabIndex = 12;
            this.gButton.Text = "G";
            this.gButton.UseVisualStyleBackColor = true;
            // 
            // hButton
            // 
            this.hButton.Location = new System.Drawing.Point(42, 168);
            this.hButton.Name = "hButton";
            this.hButton.Size = new System.Drawing.Size(73, 42);
            this.hButton.TabIndex = 13;
            this.hButton.Text = "H";
            this.hButton.UseVisualStyleBackColor = true;
            // 
            // iButton
            // 
            this.iButton.Location = new System.Drawing.Point(121, 168);
            this.iButton.Name = "iButton";
            this.iButton.Size = new System.Drawing.Size(73, 42);
            this.iButton.TabIndex = 14;
            this.iButton.Text = "I";
            this.iButton.UseVisualStyleBackColor = true;
            // 
            // jButton
            // 
            this.jButton.Location = new System.Drawing.Point(200, 168);
            this.jButton.Name = "jButton";
            this.jButton.Size = new System.Drawing.Size(73, 42);
            this.jButton.TabIndex = 15;
            this.jButton.Text = "J";
            this.jButton.UseVisualStyleBackColor = true;
            // 
            // kButton
            // 
            this.kButton.Location = new System.Drawing.Point(288, 168);
            this.kButton.Name = "kButton";
            this.kButton.Size = new System.Drawing.Size(73, 42);
            this.kButton.TabIndex = 16;
            this.kButton.Text = "K";
            this.kButton.UseVisualStyleBackColor = true;
            // 
            // lButton
            // 
            this.lButton.Location = new System.Drawing.Point(379, 168);
            this.lButton.Name = "lButton";
            this.lButton.Size = new System.Drawing.Size(73, 42);
            this.lButton.TabIndex = 17;
            this.lButton.Text = "L";
            this.lButton.UseVisualStyleBackColor = true;
            this.lButton.Click += new System.EventHandler(this.button12_Click);
            // 
            // mButton
            // 
            this.mButton.Location = new System.Drawing.Point(458, 168);
            this.mButton.Name = "mButton";
            this.mButton.Size = new System.Drawing.Size(73, 42);
            this.mButton.TabIndex = 18;
            this.mButton.Text = "M";
            this.mButton.UseVisualStyleBackColor = true;
            // 
            // nButton
            // 
            this.nButton.Location = new System.Drawing.Point(531, 168);
            this.nButton.Name = "nButton";
            this.nButton.Size = new System.Drawing.Size(73, 42);
            this.nButton.TabIndex = 19;
            this.nButton.Text = "N";
            this.nButton.UseVisualStyleBackColor = true;
            // 
            // oButton
            // 
            this.oButton.Location = new System.Drawing.Point(613, 168);
            this.oButton.Name = "oButton";
            this.oButton.Size = new System.Drawing.Size(73, 42);
            this.oButton.TabIndex = 20;
            this.oButton.Text = "O";
            this.oButton.UseVisualStyleBackColor = true;
            // 
            // pButton
            // 
            this.pButton.Location = new System.Drawing.Point(42, 227);
            this.pButton.Name = "pButton";
            this.pButton.Size = new System.Drawing.Size(73, 42);
            this.pButton.TabIndex = 21;
            this.pButton.Text = "P";
            this.pButton.UseVisualStyleBackColor = true;
            // 
            // qButton
            // 
            this.qButton.Location = new System.Drawing.Point(121, 227);
            this.qButton.Name = "qButton";
            this.qButton.Size = new System.Drawing.Size(73, 42);
            this.qButton.TabIndex = 22;
            this.qButton.Text = "Q";
            this.qButton.UseVisualStyleBackColor = true;
            // 
            // rButton
            // 
            this.rButton.Location = new System.Drawing.Point(223, 227);
            this.rButton.Name = "rButton";
            this.rButton.Size = new System.Drawing.Size(73, 42);
            this.rButton.TabIndex = 23;
            this.rButton.Text = "R";
            this.rButton.UseVisualStyleBackColor = true;
            // 
            // sButton
            // 
            this.sButton.Location = new System.Drawing.Point(313, 227);
            this.sButton.Name = "sButton";
            this.sButton.Size = new System.Drawing.Size(73, 42);
            this.sButton.TabIndex = 24;
            this.sButton.Text = "S";
            this.sButton.UseVisualStyleBackColor = true;
            // 
            // tButton
            // 
            this.tButton.Location = new System.Drawing.Point(392, 227);
            this.tButton.Name = "tButton";
            this.tButton.Size = new System.Drawing.Size(73, 42);
            this.tButton.TabIndex = 25;
            this.tButton.Text = "T";
            this.tButton.UseVisualStyleBackColor = true;
            // 
            // uButton
            // 
            this.uButton.Location = new System.Drawing.Point(485, 227);
            this.uButton.Name = "uButton";
            this.uButton.Size = new System.Drawing.Size(73, 42);
            this.uButton.TabIndex = 26;
            this.uButton.Text = "U";
            this.uButton.UseVisualStyleBackColor = true;
            // 
            // vButton
            // 
            this.vButton.Location = new System.Drawing.Point(575, 227);
            this.vButton.Name = "vButton";
            this.vButton.Size = new System.Drawing.Size(73, 42);
            this.vButton.TabIndex = 27;
            this.vButton.Text = "V";
            this.vButton.UseVisualStyleBackColor = true;
            // 
            // wButton
            // 
            this.wButton.Location = new System.Drawing.Point(665, 227);
            this.wButton.Name = "wButton";
            this.wButton.Size = new System.Drawing.Size(73, 42);
            this.wButton.TabIndex = 28;
            this.wButton.Text = "W";
            this.wButton.UseVisualStyleBackColor = true;
            // 
            // xButton
            // 
            this.xButton.Location = new System.Drawing.Point(51, 286);
            this.xButton.Name = "xButton";
            this.xButton.Size = new System.Drawing.Size(73, 42);
            this.xButton.TabIndex = 29;
            this.xButton.Text = "X";
            this.xButton.UseVisualStyleBackColor = true;
            // 
            // yButton
            // 
            this.yButton.Location = new System.Drawing.Point(156, 286);
            this.yButton.Name = "yButton";
            this.yButton.Size = new System.Drawing.Size(73, 42);
            this.yButton.TabIndex = 30;
            this.yButton.Text = "Y";
            this.yButton.UseVisualStyleBackColor = true;
            // 
            // zButton
            // 
            this.zButton.Location = new System.Drawing.Point(262, 286);
            this.zButton.Name = "zButton";
            this.zButton.Size = new System.Drawing.Size(73, 42);
            this.zButton.TabIndex = 31;
            this.zButton.Text = "Z";
            this.zButton.UseVisualStyleBackColor = true;
            // 
            // Chosen_word
            // 
            this.Chosen_word.AutoSize = true;
            this.Chosen_word.Location = new System.Drawing.Point(639, 53);
            this.Chosen_word.Name = "Chosen_word";
            this.Chosen_word.Size = new System.Drawing.Size(47, 16);
            this.Chosen_word.TabIndex = 33;
            this.Chosen_word.Text = "Words";
            this.Chosen_word.TextChanged += new System.EventHandler(this.Chosen_word_TextChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Chosen_word);
            this.Controls.Add(this.zButton);
            this.Controls.Add(this.yButton);
            this.Controls.Add(this.xButton);
            this.Controls.Add(this.wButton);
            this.Controls.Add(this.vButton);
            this.Controls.Add(this.uButton);
            this.Controls.Add(this.tButton);
            this.Controls.Add(this.sButton);
            this.Controls.Add(this.rButton);
            this.Controls.Add(this.qButton);
            this.Controls.Add(this.pButton);
            this.Controls.Add(this.oButton);
            this.Controls.Add(this.nButton);
            this.Controls.Add(this.mButton);
            this.Controls.Add(this.lButton);
            this.Controls.Add(this.kButton);
            this.Controls.Add(this.jButton);
            this.Controls.Add(this.iButton);
            this.Controls.Add(this.hButton);
            this.Controls.Add(this.gButton);
            this.Controls.Add(this.fButton);
            this.Controls.Add(this.eButton);
            this.Controls.Add(this.dButton);
            this.Controls.Add(this.cButton);
            this.Controls.Add(this.bButton);
            this.Controls.Add(this.aButton);
            this.Controls.Add(this.fifth);
            this.Controls.Add(this.fourth);
            this.Controls.Add(this.third);
            this.Controls.Add(this.second);
            this.Controls.Add(this.first);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label first;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label second;
        private System.Windows.Forms.Label third;
        private System.Windows.Forms.Label fourth;
        private System.Windows.Forms.Label fifth;
        private System.Windows.Forms.Button aButton;
        private System.Windows.Forms.Button bButton;
        private System.Windows.Forms.Button cButton;
        private System.Windows.Forms.Button dButton;
        private System.Windows.Forms.Button eButton;
        private System.Windows.Forms.Button fButton;
        private System.Windows.Forms.Button gButton;
        private System.Windows.Forms.Button hButton;
        private System.Windows.Forms.Button iButton;
        private System.Windows.Forms.Button jButton;
        private System.Windows.Forms.Button kButton;
        private System.Windows.Forms.Button lButton;
        private System.Windows.Forms.Button mButton;
        private System.Windows.Forms.Button nButton;
        private System.Windows.Forms.Button oButton;
        private System.Windows.Forms.Button pButton;
        private System.Windows.Forms.Button qButton;
        private System.Windows.Forms.Button rButton;
        private System.Windows.Forms.Button sButton;
        private System.Windows.Forms.Button tButton;
        private System.Windows.Forms.Button uButton;
        private System.Windows.Forms.Button vButton;
        private System.Windows.Forms.Button wButton;
        private System.Windows.Forms.Button xButton;
        private System.Windows.Forms.Button yButton;
        private System.Windows.Forms.Button zButton;
        private System.Windows.Forms.Label Chosen_word;
    }
}